import {
  Entity,
  CreateDateColumn,
  PrimaryGeneratedColumn,
  Column,
  OneToMany,
  UpdateDateColumn,
} from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';
import { Campaigns } from './campaigns.entity';

@Entity('organizaciones')
export class Organizations {
    
  /**
   * ID único de la Organización
   * @type {number}
   */
  @ApiProperty({ example: 1, description: 'Id único de la Organización' })
  @PrimaryGeneratedColumn()
  id: number;
    
  /**
   * CUIL de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: '20-04856975-3',
    description: 'Cuil de la Organización',
  })
  @Column({ type: 'varchar', length: 13 })
  nroDocumento: string;
    
  /**
   * // TEXTO
   * @type {boolean}
   */
  @ApiProperty({
    example: true,
    description: 'Representa si la Organización es legítima',
  })
  @Column({ type: 'bit', default: false })
  verificada: boolean;
    
  /**
   * // TEXTO
   * @type {boolean}
   */
  @ApiProperty({
    example: false,
    description: 'Indica si la Organización esta deshabilitada en el sitio',
  })
  @Column({ type: 'bit', default: false })
  deshabilitado: boolean;
    
  /**
   * Nombre Legal de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: 'Fundación Ayuda Solidaria',
    description: 'El nombre legal registrado de la organización',
  })
  @Column({ type: 'varchar', length: 255 })
  razon_social: string;
    
  /**
   * Nombre Comercial de la Organización
   * @type {string}
   */
  @ApiProperty({ example: 'INSERT-NOMBRE', description: '...' })
  @Column({ type: 'varchar', length: 50 })
  nombre_fantasia: string; // Hace falta realmente ¿? Reemplazar por mail ¿?
    
  /**
   * Descripción de la Organización
   * @type {string}
   */
  @ApiProperty({
    example:
      'La Fundación Ayuda Solidaria es una organización sin fines de lucro dedicada a mejorar la calidad de vida de personas en situación de vulnerabilidad',
    description: 'La Descripción de la Organización',
  })
  @Column({ type: 'varchar', length: 255 })
  descripcion: string;
    
  /**
   * 
   * Teléfono de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: '+54 9 11 1234-5678',
    description: 'Telefono de la Organización',
  })
  @Column({ type: 'varchar', length: 25 })
  telefono: string;
    
  /**
   * Dirección de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: 'Calle falsa 123',
    description: 'La dirección donde reside la Organización',
  })
  @Column({ type: 'varchar', length: 25 })
  direccion: string;
    
  /**
   * Sitio Web de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: 'www.fundacionayudasolidaria.org.ar',
    description: 'Sitio Web de la Organización',
  })
  @Column({ type: 'varchar', length: 255 })
  web: string;
    
  /**
   * Fecha de Registro de la Organización
   * @type {Date}
   */
  @ApiProperty({
    example: '2025-12-15T10:30:45Z',
    description: 'Fecha del Registro de la Organización en el sitio',
  })
  @CreateDateColumn({ type: 'datetime2' })
  fecha_registro: Date;
    
  /**
   * Decha del último cambio de datos de la Organización
   * @type {Date}
   */
  @ApiProperty({
    example: '2025-12-15T10:30:45Z',
    description: 'Fecha del ultimo cambio de información de la Organización',
  })
  @UpdateDateColumn({ type: 'datetime2' })
  ultimo_cambio: Date;
    
  /**
   * Campañas de la Organización
   * @type {Campaigns}
   */
  @ApiProperty({
    type: () => Campaigns,
    isArray: true,
    description: 'Campañas asociadas a la organización',
  })
  @OneToMany(() => Campaigns, (campaign) => campaign.organizacion)
  campaigns: Campaigns[];
    
  /**
   * Correo electrónico de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: 'correo@dominio.com',
    description: 'correo electronico del usuario de la empresa.',
  })
  @Column({ type: 'varchar', length: 255 })
  correo: string;
    
  /**
   * Contraseña del Usuario de la Organización
   * @type {string}
   */
  @ApiProperty({
    example: 'password123',
    description: 'contraseña del usuario de la empresa.',
  })
  @Column({ type: 'varchar', length: 255 })
  clave: string;
}
