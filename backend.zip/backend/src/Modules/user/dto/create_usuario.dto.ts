import { ApiProperty } from '@nestjs/swagger';

export class CreateUsuarioDto {
  @ApiProperty({
    example: '12345678',
    description: 'Documento del Usuario',
  })
  documento: string;

  @ApiProperty({
    example: 'usuario@email.com',
    description: 'Correo electrónico del usuario',
  })
  correo: string;

  @ApiProperty({
    example: 'PasswordSegura123',
    description: 'Clave del usuario (se almacena hasheada)',
  })
  clave: string;

  @ApiProperty({
    example: 'Juan',
    description: 'Nombre del usuario',
  })
  nombre: string;

  @ApiProperty({
    example: 'Pérez',
    description: 'Apellido del usuario',
  })
  apellido: string;

  @ApiProperty({
    example: 'USER',
    description: 'Rol del usuario dentro del sistema (USER, ADMIN)',
  })
  rol: string;
}
