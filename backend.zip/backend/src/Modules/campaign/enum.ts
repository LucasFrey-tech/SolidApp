export enum CampaignEstado {
  PENDIENTE = 'PENDIENTE',
  ACTIVA = 'ACTIVA',
  FINALIZADA = 'FINALIZADA',
}
